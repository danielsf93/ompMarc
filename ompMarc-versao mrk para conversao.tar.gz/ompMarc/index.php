<?php

require_once('ompMarc.inc.php');

return new ompMarc();